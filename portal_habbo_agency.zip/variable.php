<?php
$agencyname="NSS";
$agencyfullname="National Security Service"
?>
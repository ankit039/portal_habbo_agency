<?php 
$dbname = "localhost";
$username = "root";
$password = "";
$database = "portal_habbo_agency";

$mysqli = new mysqli($dbname, $username, $password, $database);
?>